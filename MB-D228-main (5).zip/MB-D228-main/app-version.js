// Versão da app (manual)
const APP_VERSION = 'v18';
